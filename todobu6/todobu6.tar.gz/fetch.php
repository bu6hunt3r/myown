<?php 
		// select all tasks if page is visited or refreshed
		$tasks = mysqli_query($db, "SELECT * FROM todo");

		$i = 1; 
        
            while ($row = mysqli_fetch_array($tasks)) {
            echo "<tr>";
            echo "<td>".$i."</td>";
            echo "<td class='task'>".$row['task']."</td>";
            echo "<td class='delete'><a href='index.php?del_task=".$row['id']."'>x</a>";
            $i++; 
            echo "</tr>";
        } 
?>