<?php
	require_once("crud.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>toDO List Application</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="heading">
		<h2 style="font-family: 'courier';">toDO List App</h2>
	</div>
	<div class="panel">
	<form method="post" action="index.php" class="input_form">
		<input type="text" name="task" class="task_input">
		<button type="submit" name="submit" id="add_btn" class="add_btn"></button>
	</form>
	<table>
	<thead>
		<tr>
			<th>N</th>
			<th>Tasks</th>
			<th style="width: 60px;">Action</th>
		</tr>
	</thead>

	<tbody>

		<?php require_once("fetch.php"); ?>
			
	</tbody>
</table>
	<?php if (isset($errors)) { ?>
	<p><?php echo $errors; ?></p>
    <?php } ?>
	<div class="background_img">
	<img src="bug.png" />
	</div>
</div>
</body>
</html>
