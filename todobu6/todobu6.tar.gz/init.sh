#!/bin/bash - 
#===============================================================================
#
#          FILE: init.sh
# 
#         USAGE: ./init.sh 
# 
#   DESCRIPTION: 
# 
#       OPTIONS: ---
#  REQUIREMENTS: ---
#          BUGS: ---
#         NOTES: ---
#        AUTHOR: YOUR NAME (), 
#  ORGANIZATION: 
#       CREATED: 07/10/2018 05:06:47 PM
#      REVISION:  ---
#===============================================================================

#apt-get update
#
#apt-get install -y mariadb-server mariadb-client apache2 imagemagick tesseract-ocr tesseract-ocr-deu poppler-utils git apt-transport-https
#
#apt-get install -y php7.0 php7.0-cli  php7.0-mysql  php7.0-gd  libapache2-mod-php7.0  php7.0-opcache  php7.0-zip  composer
#
#phpenmod gd
#phpenmod mysqli
#phpenmod opcache
#phpenmod zip
#
#sed -e "s/memory_limit = 128M/memory_limit = 512M/g" /etc/php/7.0/apache2/php.ini > /etc/php/7.0/apache2/php.ini.tmp && mv /etc/php/7.0/apache2/php.ini.tmp /etc/php/7.0/apache2/php.ini
#sed -e "s/memory_limit = -1/memory_limit = 512M/g" /etc/php/7.0/cli/php.ini > /etc/php/7.0/cli/php.ini.tmp && mv /etc/php/7.0/cli/php.ini.tmp /etc/php/7.0/cli/php.ini
#
#systemctl restart apache2.service
#
#install -o www-data -d /var/www/html/adar/
#
pushd /var/www/html/adar/
#
#su -s $SHELL -c 'git clone https://github.com/adlerweb/adar.git .' www-data
#
#install -o www-data -d /var/www/.composer/
#su -s $SHELL -c 'composer install' www-data
#
read -s -p "Database root password? " sqlroot
echo
sqlpw=$(base64 /dev/urandom | tr -d '/+' | dd bs=32 count=1 2>/dev/null)

sql="CREATE USER 'adar'@'localhost' IDENTIFIED BY '$sqlpw'; "
sql+="CREATE DATABASE adar; "
sql+="GRANT ALL PRIVILEGES ON \`adar\`.* TO 'adar'@'localhost'; "
sql+="FLUSH PRIVILEGES; "
sql+="USE adar; "
sql+=$(cat doc/mysql.sql)

echo "$sql" | mysql -uroot -p"$sqlroot"
unset sqlroot
unset sql

popd
