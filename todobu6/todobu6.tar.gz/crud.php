<?php
    $errors="";

	$db=mysqli_connect("localhost","todo","123456","todo");

	if(isset($_POST['submit'])) {
		if(empty($_POST['task'])) {
			$errors = "Fill in a task!";
		} else {
			$task=$_POST['task'];
			$sql="INSERT INTO todo (task) VALUES ('$task')";
			mysqli_query($db, $sql);
			header('location: index.php');
		}
	}

	// delete task
if (isset($_GET['del_task'])) {
	$id = $_GET['del_task'];

	mysqli_query($db, "DELETE FROM todo WHERE id=".$id);
	header('location: index.php');
}
?>