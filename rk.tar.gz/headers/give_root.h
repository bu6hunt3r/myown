#ifndef GIVE_ROOT_H
#define GIVE_ROOT_H

#include <linux/version.h>

extern void give_root(void);

#endif